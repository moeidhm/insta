import uuid
from typing import Dict

def generate_device_fingerprint() -> Dict[str, str]:
    """
    تولید fingerprint دستگاه برای استفاده در InstagramAdapter
    """
    return {
        "device_id": str(uuid.uuid4()),
        "app_version": "300.0.0",
        "os": "android",
        "model": "Pixel"
    }
