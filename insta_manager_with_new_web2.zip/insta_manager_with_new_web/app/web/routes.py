from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from ..db.database import SessionLocal
from ..services.account_service import AccountService

router = APIRouter()

# Dependency برای Session دیتابیس
def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """
    نمایش داشبورد همه اکانت‌ها
    """
    accounts = db.query(AccountService().model).all()
    return request.app.state.templates.TemplateResponse(
        "dashboard.html", {"request": request, "accounts": accounts}
    )

@router.post("/accounts")
async def create_account(
    username: str = Form(...),
    display_name: str = Form(None),
    bio: str = Form(None),
    db: Session = Depends(get_db),
):
    """
    ایجاد یک اکانت جدید
    """
    try:
        AccountService().create(db, username, display_name, bio)
    except Exception as e:
        print(f"❌ خطا در ایجاد اکانت: {e}")
        # می‌توانیم Redirect با پیام خطا اضافه کنیم
        return {"ok": False, "error": str(e)}

    return RedirectResponse("/", status_code=302)
