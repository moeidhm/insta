from fastapi import FastAPI, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from app.db.database import SessionLocal
from app.db.models import Account
from app.services.account_service import create_and_login_account

app = FastAPI()

# مسیر فایل‌های استاتیک (css, js, images)
app.mount("/static", StaticFiles(directory="app/web/static"), name="static")

# مسیر قالب‌ها
templates = Jinja2Templates(directory="app/web/templates")

# Dependency برای Session دیتابیس
def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
async def dashboard(request: Request):
    """
    نمایش داشبورد با همه اکانت‌ها
    """
    db = next(get_db())
    accounts = db.query(Account).all()
    return templates.TemplateResponse("dashboard.html", {"request": request, "accounts": accounts})

@app.get("/add-account")
async def add_account_page(request: Request):
    """
    نمایش فرم افزودن اکانت
    """
    return templates.TemplateResponse("add_account.html", {"request": request})

@app.post("/add-account")
async def add_account(
    username: str = Form(...),
    password: str = Form(...),
    proxy: str = Form(None)
):
    """
    ایجاد و لاگین اکانت جدید
    """
    try:
        create_and_login_account(username=username, password=password, proxy=proxy)
    except Exception as e:
        print(f"❌ خطا هنگام ایجاد اکانت: {e}")
        # در صورت نیاز می‌توان صفحه خطا یا flash message اضافه کرد
    return RedirectResponse("/", status_code=302)
