from typing import Optional, Dict
from sqlalchemy.orm import Session
from ..models import Proxy  # مطمئن شو مدل Proxy در models.py تعریف شده

class ProxyService:
    """
    سرویس مدیریت پروکسی‌ها
    """

    def pick(self, db: Session) -> Optional[Dict[str, str]]:
        """
        انتخاب اولین پروکسی فعال از دیتابیس
        """
        p = db.query(Proxy).filter(Proxy.is_active == True).first()
        if not p:
            return None

        return {
            "scheme": p.scheme,
            "host": p.host,
            "port": str(p.port),  # تبدیل به رشته برای استفاده در adapter
            "username": p.username or "",
            "password": p.password or "",
        }
