import os
from typing import Optional, Dict
from instagrapi import Client
from instagrapi.exceptions import ClientError

class InstagramAdapter:
    """
    Adapter برای مدیریت اکانت اینستاگرام با instagrapi
    - لاگین، مدیریت سشن، ویرایش پروفایل
    - پشتیبانی از پروکسی و device
    """
    def __init__(self, session_path: str, proxy: Optional[Dict[str, str]] = None, device: Optional[Dict] = None):
        self.session_path: str = session_path
        self.client: Client = Client()
        self.device: Optional[Dict] = device

        # تنظیم پروکسی
        if proxy:
            proxy_str = self._format_proxy(proxy)
            self.client.set_proxy(proxy_str)

        # Load session if exists
        if os.path.exists(session_path):
            self.client.load_settings(session_path)

        # تنظیم device
        if device:
            self.client.set_device(device)

    def _format_proxy(self, proxy: Dict[str, str]) -> str:
        """
        تبدیل دیکشنری پروکسی به رشته قابل استفاده در instagrapi
        """
        if proxy.get("username"):
            return f"{proxy['scheme']}://{proxy['username']}:{proxy['password']}@{proxy['host']}:{proxy['port']}"
        else:
            return f"{proxy['scheme']}://{proxy['host']}:{proxy['port']}"

    def login(self, username: str, password: str):
        """
        لاگین و ذخیره سشن
        """
        try:
            self.client.login(username, password)
            self.client.dump_settings(self.session_path)
        except ClientError as e:
            print(f"❌ خطا در لاگین: {e}")
            raise

    def update_profile(self, name: Optional[str] = None, bio: Optional[str] = None, avatar_path: Optional[str] = None):
        """
        ویرایش اطلاعات پروفایل
        """
        try:
            if name:
                self.client.account_edit(name=name)
            if bio:
                self.client.account_edit(biography=bio)
            if avatar_path:
                self.client.account_change_picture(avatar_path)
        except ClientError as e:
            print(f"❌ خطا در بروزرسانی پروفایل: {e}")
            raise

    def get_profile_info(self) -> Dict[str, str]:
        """
        اطلاعات پروفایل مانند full_name، bio و profile_pic_url
        """
        info = self.client.account_info()
        return {
            "full_name": info.full_name,
            "bio": info.biography,
            "profile_pic_url": info.profile_pic_url
        }
