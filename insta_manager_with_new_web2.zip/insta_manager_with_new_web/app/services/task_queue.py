import asyncio
import random
from typing import Callable, Any

class TaskQueue:
    """
    صف وظایف انسانی برای هر اکانت
    - اجرای taskها با تاخیر تصادفی برای جلوگیری از شناسایی الگوریتمی
    """

    def __init__(self, min_delay: int = 5, max_delay: int = 15):
        self.queue = asyncio.Queue()
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.running = False

    async def worker(self):
        """
        اجرای مداوم تسک‌ها
        """
        while True:
            func, args, kwargs = await self.queue.get()
            try:
                print(f"🚀 اجرای task: {func.__name__} با args={args} kwargs={kwargs}")
                if asyncio.iscoroutinefunction(func):
                    await func(*args, **kwargs)
                else:
                    func(*args, **kwargs)
                # تاخیر تصادفی بین taskها
                delay = random.randint(self.min_delay, self.max_delay)
                await asyncio.sleep(delay)
            except Exception as e:
                print(f"❌ خطا در اجرای task: {e}")
            finally:
                self.queue.task_done()

    def add_task(self, func: Callable[..., Any], *args, **kwargs):
        """
        اضافه کردن یک تسک به صف
        """
        self.queue.put_nowait((func, args, kwargs))

    async def start(self, num_workers: int = 1):
        """
        شروع اجرای workerها
        """
        if self.running:
            return
        self.running = True
        tasks = [asyncio.create_task(self.worker()) for _ in range(num_workers)]
        await self.queue.join()
        for t in tasks:
            t.cancel()
