import os
from typing import Optional, Dict
from instagrapi import Client
from instagrapi.exceptions import ClientError, ClientLoginRequired

class InstagramAdapter:
    """
    Adapter برای مدیریت اکانت اینستاگرام با instagrapi
    """
    def __init__(self, session_path: str, proxy: Optional[str] = None, device: Optional[Dict] = None):
        self.client = Client()
        self.session_path = session_path

        if proxy:
            self.client.set_proxy(proxy)

        if device:
            self.client.set_device(device)

    def login(self, username: str, password: str) -> dict:
        """
        لاگین با یوزرنیم و پسورد و ذخیره سشن
        """
        try:
            if os.path.exists(self.session_path):
                self.client.load_settings(self.session_path)
                # تست سشن
                try:
                    self.client.account_info()
                except ClientLoginRequired:
                    self.client.login(username, password)
            else:
                self.client.login(username, password)
                self.client.dump_settings(self.session_path)

            return self.client.account_info().dict()
        except ClientError as e:
            print(f"❌ خطا در لاگین: {e}")
            raise

    def get_profile_info(self) -> dict:
        """
        اطلاعات پروفایل مانند full_name، bio و profile_pic_url
        """
        info = self.client.account_info()
        return {
            "full_name": info.full_name,
            "bio": info.biography,
            "profile_pic_url": info.profile_pic_url
        }
