import os
from typing import Optional
from sqlalchemy.orm import Session
from app.core.instagram_client import InstagramAdapter
from app.db.models import Account
from app.db.database import SessionLocal

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)


def create_and_login_account(username: str, password: str, proxy: Optional[str] = None) -> Account:
    """
    لاگین به اینستاگرام با instagrapi، ساخت سشن و ذخیره اطلاعات اکانت در دیتابیس
    """
    session_path = f"{SESSIONS_DIR}/{username}.json"
    adapter = InstagramAdapter(session_path=session_path, proxy=proxy, device=None)

    try:
        adapter.login(username, password)
        profile = adapter.get_profile_info()

        db = SessionLocal()
        account = Account(
            username=username,
            password=password,  # ⚠️ بعداً Hash کنید
            session_file=session_path,
            proxy=proxy,
            full_name=profile.get("full_name"),
            bio=profile.get("bio"),
            profile_pic_path=profile.get("profile_pic_url"),
            is_active=True
        )
        db.add(account)
        db.commit()
        db.refresh(account)
        return account
    finally:
        db.close()


class AccountService:
    """
    سرویس مدیریت اکانت‌ها بدون استفاده از متدهای اضافی که در مدل وجود ندارد
    """
    def create(self, db: Session, username: str, bio: Optional[str] = None) -> Account:
        """
        ساخت اکانت جدید در دیتابیس بدون لاگین اینستاگرام
        """
        acc = Account(
            username=username,
            bio=bio,
            is_active=False
        )
        db.add(acc)
        db.commit()
        db.refresh(acc)
        return acc
