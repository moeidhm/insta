import os
from typing import Final
from ..config import settings

class SessionService:
    """
    مدیریت مسیر و ساخت پوشه سشن‌ها برای اکانت‌ها
    """
    def __init__(self):
        # ایجاد پوشه سشن‌ها در صورت عدم وجود
        os.makedirs(settings.SESSIONS_DIR, exist_ok=True)
        self.sessions_dir: Final[str] = settings.SESSIONS_DIR

    def path_for(self, username: str) -> str:
        """
        مسیر فایل سشن برای یک اکانت مشخص
        """
        return os.path.join(self.sessions_dir, f"{username}.json")
