import asyncio
from typing import Callable, Any, Dict
from app.core.instagram_client import InstagramAdapter
from app.services.task_queue import TaskQueue

class AccountWrapper:
    """
    Wrapper برای هر اکانت اینستاگرام
    - هر اکانت یک TaskQueue مخصوص دارد
    """
    def __init__(self, username: str, adapter: InstagramAdapter):
        self.username: str = username
        self.adapter: InstagramAdapter = adapter
        self.queue: TaskQueue = TaskQueue(min_delay=10, max_delay=30)
        self.is_active: bool = False

    def add_task(self, func: Callable[..., Any], *args, **kwargs):
        """
        اضافه کردن task به صف اکانت
        """
        self.queue.add_task(func, *args, **kwargs)

    async def start(self):
        """
        شروع اجرای صف اکانت
        """
        self.is_active = True
        await self.queue.start()
        self.is_active = False


class MultiAccountManager:
    """
    مدیریت چند اکانت همزمان
    """
    def __init__(self):
        self.accounts: Dict[str, AccountWrapper] = {}

    def add_account(self, username: str, adapter: InstagramAdapter):
        """
        اضافه کردن اکانت جدید
        """
        self.accounts[username] = AccountWrapper(username, adapter)

    def add_task(self, username: str, func: Callable[..., Any], *args, **kwargs):
        """
        اضافه کردن task به اکانت مشخص
        """
        if username in self.accounts:
            self.accounts[username].add_task(func, *args, **kwargs)

    async def start_all(self):
        """
        اجرای همه صف‌ها به صورت همزمان
        """
        tasks = [acc.start() for acc in self.accounts.values()]
        await asyncio.gather(*tasks)
