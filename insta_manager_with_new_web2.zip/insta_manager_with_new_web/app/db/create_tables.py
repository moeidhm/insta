# create_tables.py
from app.db.database import Base, engine
from app.db import models  # import مدل‌ها

Base.metadata.create_all(bind=engine)
print("✅ تمام جدول‌ها ایجاد شدند.")