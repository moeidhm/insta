from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# ===========================
# تنظیمات دیتابیس PostgreSQL
# ===========================
# جایگزین کنید username, password و insta_db با مقادیر واقعی
DATABASE_URL = "postgresql://username:password@localhost/insta_db"

# ===========================
# Engine و Session
# ===========================
engine = create_engine(DATABASE_URL, echo=True)  # echo=True برای لاگ SQL، در تولید False شود
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base برای مدل‌ها
Base = declarative_base()

# ===========================
# تابع کمکی برای تست اتصال
# ===========================
def test_db_connection():
    try:
        db = SessionLocal()
        db.execute("SELECT 1")
        db.close()
        print("✅ اتصال به دیتابیس موفق بود.")
    except Exception as e:
        print(f"❌ خطا در اتصال به دیتابیس: {e}")
