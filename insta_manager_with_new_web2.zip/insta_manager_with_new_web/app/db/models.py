from sqlalchemy import Column, Integer, String, Boolean
from .database import Base

class Account(Base):
    """
    مدل اکانت اینستاگرام
    """
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(150), unique=True, index=True, nullable=False)
    password = Column(String(200), nullable=False)  # بعداً Hash کنید
    session_file = Column(String(200), nullable=False)
    proxy = Column(String(200), nullable=True)

    full_name = Column(String(200), nullable=True)
    bio = Column(String(500), nullable=True)
    profile_pic_path = Column(String(500), nullable=True)

    is_active = Column(Boolean, default=False)
