from pydantic import BaseSettings

class Settings(BaseSettings):
    """
    تنظیمات پروژه
    """
    DATABASE_URL: str = "postgresql+psycopg2://user:pass@localhost:5432/insta"
    SESSIONS_DIR: str = "sessions"
    DEBUG: bool = True

    class Config:
        env_file = ".env"  # امکان بارگذاری مقادیر از فایل .env
        env_file_encoding = "utf-8"

# نمونه global از تنظیمات
settings = Settings()
