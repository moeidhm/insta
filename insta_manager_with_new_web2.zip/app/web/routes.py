
from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..services.account_service import AccountService

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return request.app.state.templates.TemplateResponse(
        "dashboard.html", {"request": request}
    )

@router.post("/accounts")
async def create_account(
    username: str = Form(...),
    display_name: str = Form(None),
    bio: str = Form(None),
    db: Session = Depends(get_db),
):
    AccountService().create(db, username, display_name, bio)
    return {"ok": True}
