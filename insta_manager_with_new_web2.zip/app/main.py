
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .web.routes import router
from .db import Base, engine

app = FastAPI()
Base.metadata.create_all(bind=engine)

app.mount("/static", StaticFiles(directory="app/web/static"), name="static")
app.state.templates = Jinja2Templates(directory="app/web/templates")
app.include_router(router)
