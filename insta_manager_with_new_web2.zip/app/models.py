
from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON
from sqlalchemy.sql import func
from .db import Base

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, index=True)
    display_name = Column(String)
    bio = Column(String)
    profile_pic_path = Column(String)
    proxy_id = Column(Integer)
    device_fingerprint = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class SessionRecord(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer)
    session_file = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Proxy(Base):
    __tablename__ = "proxies"
    id = Column(Integer, primary_key=True)
    scheme = Column(String)
    host = Column(String)
    port = Column(Integer)
    username = Column(String, nullable=True)
    password = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
