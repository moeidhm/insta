
from pydantic import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+psycopg2://user:pass@localhost:5432/insta"
    SESSIONS_DIR: str = "sessions"
    DEBUG: bool = True

settings = Settings()
