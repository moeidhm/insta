
import uuid

def generate_device_fingerprint() -> dict:
    return {
        "device_id": str(uuid.uuid4()),
        "app_version": "300.0.0",
        "os": "android",
        "model": "Pixel"
    }
