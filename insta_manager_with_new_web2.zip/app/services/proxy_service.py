
from sqlalchemy.orm import Session
from ..models import Proxy

class ProxyService:
    def pick(self, db: Session) -> dict | None:
        p = db.query(Proxy).filter(Proxy.is_active == True).first()
        if not p:
            return None
        return {
            "scheme": p.scheme,
            "host": p.host,
            "port": p.port,
            "username": p.username,
            "password": p.password,
        }
