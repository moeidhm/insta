
import asyncio
from .instagram_adapter import InstagramAdapter
from .task_queue import TaskQueue

class AccountWrapper:
    def __init__(self, username: str, adapter: InstagramAdapter):
        self.username = username
        self.adapter = adapter
        self.queue = TaskQueue(min_delay=10, max_delay=30)

    def add_task(self, func, *args, **kwargs):
        self.queue.add_task(func, *args, **kwargs)

    async def start(self):
        await self.queue.start()


class MultiAccountManager:
    def __init__(self):
        self.accounts: dict[str, AccountWrapper] = {}

    def add_account(self, username: str, adapter: InstagramAdapter):
        self.accounts[username] = AccountWrapper(username, adapter)

    def add_task(self, username: str, func, *args, **kwargs):
        if username in self.accounts:
            self.accounts[username].add_task(func, *args, **kwargs)

    async def start_all(self):
        tasks = [acc.start() for acc in self.accounts.values()]
        await asyncio.gather(*tasks)
