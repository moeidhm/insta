
from instagrapi import Client

class InstagramAdapter:
    def __init__(self, session_path: str, proxy: dict | None, device: dict):
        self.session_path = session_path
        self.client = Client()
        if proxy:
            if proxy.get("username"):
                self.client.set_proxy(
                    f"{proxy['scheme']}://{proxy['username']}:{proxy['password']}@{proxy['host']}:{proxy['port']}"
                )
            else:
                self.client.set_proxy(
                    f"{proxy['scheme']}://{proxy['host']}:{proxy['port']}"
                )
        # device info stored for traceability (instagrapi manages internally)
        self.device = device
        if os.path.exists(session_path):
            self.client.load_settings(session_path)

    def login(self, username: str, password: str):
        self.client.login(username, password)
        self.client.dump_settings(self.session_path)

    def update_profile(self, name: str | None, bio: str | None, avatar_path: str | None):
        if name:
            self.client.account_edit(name=name)
        if bio:
            self.client.account_edit(biography=bio)
        if avatar_path:
            self.client.account_change_picture(avatar_path)
