
from sqlalchemy.orm import Session
from ..models import Account
from ..utils.device import generate_device_fingerprint

class AccountService:
    def create(self, db: Session, username: str, display_name: str | None, bio: str | None):
        acc = Account(
            username=username,
            display_name=display_name,
            bio=bio,
            device_fingerprint=generate_device_fingerprint(),
        )
        db.add(acc)
        db.commit()
        db.refresh(acc)
        return acc
