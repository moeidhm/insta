from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.db import SessionLocal
from app.db.models import Account

app = FastAPI()

# Static folder
app.mount("/static", StaticFiles(directory="app/web/static"), name="static")

# Templates
templates = Jinja2Templates(directory="app/web/templates")

@app.get("/")
async def dashboard(request: Request):
    db = SessionLocal()
    accounts = db.query(Account).all()
    db.close()
    return templates.TemplateResponse(
        "dashboard.html", {"request": request, "accounts": accounts}
    )
