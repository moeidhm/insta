from fastapi import FastAPI, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from app.db.database import SessionLocal
from app.db.models import Account
from app.services.account_service import create_and_login_account

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/web/static"), name="static")
templates = Jinja2Templates(directory="app/web/templates")

@app.get("/")
async def dashboard(request: Request):
    db = SessionLocal()
    accounts = db.query(Account).all()
    db.close()
    return templates.TemplateResponse("dashboard.html", {"request": request, "accounts": accounts})

@app.get("/add-account")
async def add_account_page(request: Request):
    return templates.TemplateResponse("add_account.html", {"request": request})

@app.post("/add-account")
async def add_account(username: str = Form(...), password: str = Form(...), proxy: str = Form(None)):
    create_and_login_account(username, password, proxy)
    return RedirectResponse("/", status_code=302)
