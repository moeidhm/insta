import asyncio
from app.core.instagram_client import InstagramAdapter
from app.services.task_queue import TaskQueue

class AccountWrapper:
    def __init__(self, username: str, adapter: InstagramAdapter):
        self.username = username
        self.adapter = adapter
        self.queue = TaskQueue(min_delay=10, max_delay=30)
        self.is_active = False

    def add_task(self, func, *args, **kwargs):
        self.queue.add_task(func, *args, **kwargs)

    async def start(self):
        self.is_active = True
        await self.queue.start()
        self.is_active = False

class MultiAccountManager:
    def __init__(self):
        self.accounts: dict[str, AccountWrapper] = {}

    def add_account(self, username: str, adapter: InstagramAdapter):
        self.accounts[username] = AccountWrapper(username, adapter)

    def add_task(self, username: str, func, *args, **kwargs):
        if username in self.accounts:
            self.accounts[username].add_task(func, *args, **kwargs)

    async def start_all(self):
        tasks = [acc.start() for acc in self.accounts.values()]
        await asyncio.gather(*tasks)
