
from sqlalchemy.orm import Session
from ..models import Account
from ..utils.device import generate_device_fingerprint
import os
from app.core.instagram_client import InstagramAdapter
from app.db.models import Account
from app.db.database import SessionLocal
import os
from app.core.instagram_client import InstagramAdapter
from app.db.models import Account
from app.db.database import SessionLocal

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)

def create_and_login_account(username: str, password: str, proxy: str | None = None):
    session_path = f"{SESSIONS_DIR}/{username}.json"
    adapter = InstagramAdapter(session_path=session_path, proxy=proxy, device=None)

    adapter.login(username, password)
    profile = adapter.get_profile_info()

    db = SessionLocal()
    account = Account(
        username=username,
        password=password,
        session_file=session_path,
        proxy=proxy,
        full_name=profile["full_name"],
        bio=profile["bio"],
        profile_pic_path=profile["profile_pic_url"],
        is_active=True
    )
    db.add(account)
    db.commit()
    db.close()
    return account


class AccountService:
    def create(self, db: Session, username: str, display_name: str | None, bio: str | None):
        acc = Account(
            username=username,
            display_name=display_name,
            bio=bio,
            device_fingerprint=generate_device_fingerprint(),
        )
        db.add(acc)
        db.commit()
        db.refresh(acc)
        return acc
