from instagrapi import Client
import os

class InstagramAdapter:
    def __init__(self, session_path: str, proxy: str | None = None, device: dict | None = None):
        self.client = Client()
        self.session_path = session_path

        if proxy:
            self.client.set_proxy(proxy)

        if device:
            self.client.set_device(device)

    def login(self, username: str, password: str):
        if os.path.exists(self.session_path):
            self.client.load_settings(self.session_path)
            self.client.login(username, password)
        else:
            self.client.login(username, password)
            self.client.dump_settings(self.session_path)

        return self.client.account_info()

    def get_profile_info(self):
        info = self.client.account_info()
        return {
            "full_name": info.full_name,
            "bio": info.biography,
            "profile_pic_url": info.profile_pic_url
        }
