from sqlalchemy import Column, Integer, String, Boolean
from .database import Base

class Account(Base):
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)
    session_file = Column(String)
    proxy = Column(String, nullable=True)

    full_name = Column(String, nullable=True)
    bio = Column(String, nullable=True)
    profile_pic_path = Column(String, nullable=True)

    is_active = Column(Boolean, default=False)

from app.db.database import Base, engine
from app.db import models

Base.metadata.create_all(bind=engine)
