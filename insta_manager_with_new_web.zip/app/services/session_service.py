
import os
from ..config import settings

class SessionService:
    def __init__(self):
        os.makedirs(settings.SESSIONS_DIR, exist_ok=True)

    def path_for(self, username: str) -> str:
        return os.path.join(settings.SESSIONS_DIR, f"{username}.json")
