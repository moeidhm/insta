
import asyncio
import random
from typing import Callable

class TaskQueue:
    def __init__(self, min_delay: int = 5, max_delay: int = 15):
        """
        Queue for tasks per account
        min_delay, max_delay: delay in seconds between tasks
        """
        self.queue = asyncio.Queue()
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.running = False

    async def worker(self):
        while True:
            func, args, kwargs = await self.queue.get()
            try:
                print(f"Running task {func.__name__} with args {args}")
                await func(*args, **kwargs)
                delay = random.randint(self.min_delay, self.max_delay)
                print(f"Waiting {delay}s before next task...")
                await asyncio.sleep(delay)
            except Exception as e:
                print(f"Task error: {e}")
            finally:
                self.queue.task_done()

    def add_task(self, func: Callable, *args, **kwargs):
        self.queue.put_nowait((func, args, kwargs))

    async def start(self, num_workers: int = 1):
        if self.running:
            return
        self.running = True
        tasks = [asyncio.create_task(self.worker()) for _ in range(num_workers)]
        await self.queue.join()
        for t in tasks:
            t.cancel()
